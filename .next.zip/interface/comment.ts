export interface Comment {
    id: number;
    name: string;
    content: string;
    phone: string;
    createdAt: string;
    articleId: number;
}
